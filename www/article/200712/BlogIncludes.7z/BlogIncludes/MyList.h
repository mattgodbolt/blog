// MyList.h
#include <list>
template<typename T>
class MyList : public std::list<T> {};
