// SimpleClient.cpp : Defines the entry point for the console application.
//
#include "NewAverager.h"

void SimpleTest()
{
	Averager a;
	for (int i = 0; i < 10; ++i)
		a.Add(i);
}
