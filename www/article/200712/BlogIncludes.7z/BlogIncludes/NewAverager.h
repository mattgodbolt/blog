// NewAverager.h
template<class T> class MyList;

class Averager
{
public:
	Averager();
	// Add a single int to the running average.
	void Add(int);
	// Add a list of ints to the running average.
	void Add(const MyList<int>&);
	// Get the current average.
	int GetAverage() const;
};
