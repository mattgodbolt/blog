// NaiveAverager.h
namespace std { template<typename T> class list; } 

class Averager
{
public:
	Averager();
	// Add a single int to the running average.
	void Add(int);
	// Add a list of ints to the running average.
	void Add(const std::list<int>&);
	// Get the current average.
	int GetAverage() const;
private:
	int mNumAdded;  // number of ints added
	int mTotal;     // running total so far
};
