/*
    This file is part of the LCDGraphics library for the Weebox.

    LCDGraphics is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    Foobar is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with LCDGraphics.  If not, see <http://www.gnu.org/licenses/>.
*/

#ifndef INCLUDED_LCDGRAPHICS_COLOUR_H
#define INCLUDED_LCDGRAPHICS_COLOUR_H

namespace LCDGraphics
{
	class Colour
	{
	public:
		Colour();
		Colour(int iValue);
		Colour(int iRed, int iGreen, int iBlue);

		unsigned char GetRed() const { return mRed; }
		unsigned char GetGreen() const { return mGreen; }
		unsigned char GetBlue() const { return mBlue; }

	private:
		unsigned char mRed;
		unsigned char mGreen;
		unsigned char mBlue;
	};
}

#endif
